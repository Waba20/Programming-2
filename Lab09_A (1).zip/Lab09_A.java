

class Student {
    void Play() {
        System.out.println("We are proud students of NUST-");
    }
}

class FT extends Student {
    void FTStudy() {
        System.out.println("Mr Steven - I am in FT programme");
    }
}

class PT extends Student {
    void PTStudy() {
        System.out.println("Ms Jane - I am in PT programme");
    }
}

public class Lab09_A {
    public static void main(String args[]) {

        System.out.println("Demonstration of Hierarchical inheritance:\n");

    
        FT ft = new FT();
        PT pt = new PT();

        
        ft.Play();      
        ft.FTStudy();    
        pt.PTStudy();   
    }
}