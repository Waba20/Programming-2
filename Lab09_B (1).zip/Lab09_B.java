class Animal {
    public void animalSound() {
        System.out.println("The animal makes a sound");
    }
}

class Pig extends Animal {
    public void animalSound() {
        System.out.println("The pig says: wee wee");
    }
}

class Dog extends Animal {
    public void animalSound() {
        System.out.println("The dog says: bow wow");
    }
}

class Bird extends Animal {
    public void animalSound() {
        System.out.println("The Bird: Whistle");
    }
}


class Rat extends Animal {
    public void animalSound() {
        System.out.println("The Rat: Squeak");
    }
}


class Lion extends Animal {
    public void animalSound() {
        System.out.println("The Lion: Roar");
    }
}

public class Lab09_B {
    public static void main(String[] args) {

        System.out.println("Demonstration of Polymophism:");

        Animal myAnimal = new Animal();
        Animal myPig = new Pig();
        Animal myDog = new Dog();
        Animal myBird = new Bird();
        Animal myRat = new Rat();
        Animal myLion = new Lion();

        myAnimal.animalSound();
        myPig.animalSound();
        myDog.animalSound();
        myBird.animalSound();
        myRat.animalSound();
        myLion.animalSound();
    }
}