
// Start of the program

class C {
    public void Print() {
        System.out.println("C is the Parent Class to all A,B,Lab08_C");
    }
}

class A extends C {
    public void Print() {
        System.out.println("A has Single Inheritance with C and shares Hierarchy with B");
    }
}

class B extends C {
    public void Print() {
        System.out.println("B has Single Inheritance with C and shares Hierarchy with A");
    }
}

public class Lab08_C extends A {
    public void Print() {
        System.out.println("Lab08_C has Single Inheritance with A and Multi-Level inheritance with C");
    }

    public static void main(String args[]) {

        System.out.println("Demonstration of Hybrid Inheritance:");

        A w = new A();
        B x = new B();
        C y = new C();
        Lab08_C z = new Lab08_C();

        y.Print();
        w.Print();
        x.Print();
        z.Print();
    }
}