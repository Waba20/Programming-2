import java.util.Scanner;

public class quad {

    private int x;
    private int y;

    public quad() {}

    public quad(int x, int y){
        this.x = x;
        this.y = y;
    }

    public String getQuad(){

        if(x > 0 && y > 0){
            return "Point ("+x+","+y+") is in Quadrant I";
        }
        else if(x < 0 && y > 0){
            return "Point ("+x+","+y+") is in Quadrant II";
        }
        else if(x < 0 && y < 0){
            return "Point ("+x+","+y+") is in Quadrant III";
        }
        else if(x > 0 && y < 0){
            return "Point ("+x+","+y+") is in Quadrant IV";
        }
        else if(x == 0 && y == 0){
            return "Point (0,0) is at the centre and not in any Quadrant";
        }
        else{
            return "Point ("+x+","+y+") is on an axis";
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int x = sc.nextInt();
        int y = sc.nextInt();

        quad q = new quad(x,y);

        System.out.println(q.getQuad());
    }
}

