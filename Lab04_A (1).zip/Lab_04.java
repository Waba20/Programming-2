import java.util.Scanner;

class model {

    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String studentNumber;

    private static int studentCount = 0;

    public model(String firstName, String lastName, int age, String gender) {
        studentCount++;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.studentNumber = "22201" + String.format("%03d", studentCount);
    }

    
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getStudentNumber() { return studentNumber; }
}

public class Lab_04 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        sc.nextLine(); // consume the remaining newline

        if(n <= 0) {
            System.out.println("Please provide a positive count of students");
            sc.close();
            return;
        }

        model[] students = new model[n];

        for(int i = 0; i < n; i++) {
            String firstName = sc.next();
            String lastName = sc.next();
            int age = sc.nextInt();
            String gender = sc.next();

            if(age <= 0) {
                System.out.println("Please provide a valid student age.");
                sc.close();
                return;
            }

            students[i] = new model(firstName, lastName, age, gender);
        }

        for(int i = 0; i < n; i++) {
            System.out.println("Full names : " + students[i].getFirstName() + " " + students[i].getLastName());
            System.out.println("Age : " + students[i].getAge());
            System.out.println("Gender : " + students[i].getGender());
            System.out.println("Student Number : " + students[i].getStudentNumber());
            System.out.println();
        }

        sc.close();
    }
}