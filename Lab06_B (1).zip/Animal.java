class Animal1 {
    
    private String name;

    public void setName(String name) {
        this.name = name;
    }

    
    public String getName() {
        return name;
    }

    public void eat() {
        
        System.out.println("I can eat very well");
    }
}

class Dog extends Animal1 {
    
    public void display() {
        
        System.out.println("My surname is " + getName());
    }
}

public class Animal {
    public static void main(String[] args) {

        Dog labrador = new Dog();
        
        
        labrador.setName("Rohuda");
        
        labrador.display();
        
    
        labrador.eat();
    }
}