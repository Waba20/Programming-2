import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
    
        System.out.print("Enter a Number: ");
        int num = input.nextInt();
        
    
        if (num < 0) {
            System.out.println("Number cannot be less than 0");
        } else {
            
            findCube(num);
        }
        
        
    }
    
    
    public static void findCube(int num) {
        
        int cube = num * num * num;
        
    
        System.out.println("The Cube is: " + cube);
    }
}