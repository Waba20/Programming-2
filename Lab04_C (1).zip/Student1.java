class Student {
    
    String studName, studDept;
    int test1, test2, assign1, studNumber, totalMark;
}

public class Student1 {
    public static void main(String[] args) {

        
        Student stud = new Student();

        
        stud.studName = "Teresia Aka";
        stud.studNumber = 93100191;
        stud.studDept = "Computer Science";
        stud.test1 = 23;
        stud.test2 = 18;
        stud.assign1 = 20;

        
        stud.totalMark = stud.test1 + stud.test2 + stud.assign1;


        System.out.println("Student Name: " + stud.studName);
        System.out.println("Student Number: " + stud.studNumber);
        System.out.println("Student Department: " + stud.studDept);
        System.out.println("Test1: " + stud.test1);
        System.out.println("Test2: " + stud.test2);
        System.out.println("Assignment: " + stud.assign1);
        System.out.println("Total Mark: " + stud.totalMark);
    }
}